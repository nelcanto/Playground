targetfile=$1;shift
cat $@ > $targetfile

