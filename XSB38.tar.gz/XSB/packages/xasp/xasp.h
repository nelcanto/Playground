
#define smodels    ((Smodels *) (th->_smodels))
#define api        ((Api *) (th->_api))
#define atoms       ((Atom **) (th->_atoms))
#define curatom    (th->_curatom)
#define totatoms   (th->_totatoms)
